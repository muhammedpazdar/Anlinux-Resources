Others menu
-----------
This menu contains all not-frequently used (but nice) options.

.. include:: others/options.rst
.. include:: others/external.rst
.. include:: others/advanced.rst



