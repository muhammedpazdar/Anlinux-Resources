#ifndef VERIFYSSID_H_INCLUDED
#define VERIFYSSID_H_INCLUDED

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int verifyssid(const unsigned char * s);

#ifdef __cplusplus
};
#endif

#endif // VERIFYSSID_H_INCLUDED
